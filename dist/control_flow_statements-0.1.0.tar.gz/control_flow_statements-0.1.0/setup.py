from setuptools import setup

setup(
   name='control_flow_statements',
   version='0.1.0',
   packages=['control_flow_statements'],
   description='This is control_flow_statements Test',
   install_requires=[
       "requests",
   ]
)